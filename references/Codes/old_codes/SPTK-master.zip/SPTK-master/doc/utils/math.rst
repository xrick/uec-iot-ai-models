math
====

.. doxygenclass:: sptk::Matrix
   :members:

.. doxygenclass:: sptk::Matrix2D
   :members:

.. doxygenclass:: sptk::SymmetricMatrix
   :members:

.. doxygenclass:: sptk::SymmetricSystemSolver
   :members:

.. doxygenclass:: sptk::ToeplitzPlusHankelSystemSolver
   :members:

.. doxygenclass:: sptk::VandermondeSystemSolver
   :members:
