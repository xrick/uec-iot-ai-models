misc
====

.. doxygenfile:: misc_utils.cc
