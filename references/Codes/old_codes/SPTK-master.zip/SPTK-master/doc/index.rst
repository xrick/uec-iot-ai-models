****
SPTK
****
`SPTK <https://github.com/sp-nitech/SPTK>`_ is a software for speech signal processing tools, e.g., LPC analysis, PARCOR analysis, LSP analysis, PARCOR synthesis filter, LSP synthesis filter, vector quantization techniques, and other extended versions of them.

.. toctree::
   :glob:
   :maxdepth: 1
   :caption: Command references

   main/*

.. toctree::
   :glob:
   :maxdepth: 1
   :caption: Utility references

   utils/*


Indices
=======
* :ref:`genindex`
