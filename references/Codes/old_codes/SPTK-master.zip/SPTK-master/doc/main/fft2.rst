.. _fft2:

fft2
====

.. doxygenfile:: fft2.cc

.. seealso:: :ref:`fft`  :ref:`ifft2`  :ref:`fftr2`

.. doxygenclass:: sptk::TwoDimensionalFastFourierTransform
   :members:
