.. _fbank:

fbank
=====

.. doxygenfile:: fbank.cc

.. seealso:: :ref:`mfcc`

.. doxygenclass:: sptk::MelFilterBankAnalysis
   :members:
