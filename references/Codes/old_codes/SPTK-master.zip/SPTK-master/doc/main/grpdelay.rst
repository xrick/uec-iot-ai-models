.. _grpdelay:

grpdelay
========

.. doxygenfile:: grpdelay.cc

.. seealso:: :ref:`phase`

.. doxygenclass:: sptk::FilterCoefficientsToGroupDelay
   :members:
