.. _acorr:

acorr
=====

.. doxygenfile:: acorr.cc

.. seealso:: :ref:`c2acr`  :ref:`levdur`  :ref:`lpc`

.. doxygenclass:: sptk::AutocorrelationAnalysis
   :members:

.. doxygenclass:: sptk::WaveformToAutocorrelation
   :members:

.. doxygenclass:: sptk::SpectrumToAutocorrelation
   :members:
