.. _c2mpir:

c2mpir
======

.. doxygenfile:: c2mpir.cc

.. seealso:: :ref:`c2acr`  :ref:`mpir2c`  :ref:`mgc2mgc`

.. doxygenclass:: sptk::CepstrumToMinimumPhaseImpulseResponse
   :members:
