.. _clip:

clip
====

.. doxygenfile:: clip.cc

.. seealso:: :ref:`sopr`
