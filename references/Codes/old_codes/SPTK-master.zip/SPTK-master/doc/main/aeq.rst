.. _aeq:

aeq
===

.. doxygenfile:: aeq.cc
