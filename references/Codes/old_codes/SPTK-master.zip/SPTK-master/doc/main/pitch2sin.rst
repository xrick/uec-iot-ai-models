.. _pitch2sin:

pitch2sin
=========

.. doxygenfile:: pitch2sin.cc

.. seealso:: :ref:`pitch`  :ref:`excite`

.. doxygenclass:: sptk::SinusoidalGeneration
   :members:
