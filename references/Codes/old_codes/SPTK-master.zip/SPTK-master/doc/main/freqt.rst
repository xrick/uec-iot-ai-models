.. _freqt:

freqt
=====

.. doxygenfile:: freqt.cc

.. seealso:: :ref:`mgc2mgc`

.. doxygenclass:: sptk::FrequencyTransform
   :members:
