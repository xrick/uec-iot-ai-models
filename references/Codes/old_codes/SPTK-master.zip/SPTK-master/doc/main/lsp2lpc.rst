.. _lsp2lpc:

lsp2lpc
=======

.. doxygenfile:: lsp2lpc.cc

.. seealso:: :ref:`lpc2lsp`

.. doxygenclass:: sptk::LineSpectralPairsToLinearPredictiveCoefficients
   :members:
