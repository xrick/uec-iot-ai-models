.. _ipqmf:

ipqmf
=====

.. doxygenfile:: ipqmf.cc

.. seealso:: :ref:`pqmf`

.. doxygenclass:: sptk::InversePseudoQuadratureMirrorFilterBanks
   :members:
