.. _impulse:

impulse
=======

.. doxygenfile:: impulse.cc

.. seealso:: :ref:`step`  :ref:`train`  :ref:`ramp`  :ref:`sin`
