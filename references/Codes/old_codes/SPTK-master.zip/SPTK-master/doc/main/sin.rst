.. _sin:

sin
===

.. doxygenfile:: sin.cc

.. seealso:: :ref:`impulse`  :ref:`step`  :ref:`ramp`  :ref:`train`
