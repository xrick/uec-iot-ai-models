.. _fftr2:

fftr2
=====

.. doxygenfile:: fftr2.cc

.. seealso:: :ref:`fftr`  :ref:`ifft2`  :ref:`fft2`

.. doxygenclass:: sptk::TwoDimensionalRealValuedFastFourierTransform
   :members:
