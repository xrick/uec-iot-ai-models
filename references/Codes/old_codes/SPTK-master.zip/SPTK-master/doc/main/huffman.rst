.. _huffman:

huffman
=======

.. doxygenfile:: huffman.cc

.. seealso:: :ref:`huffman_encode`  :ref:`huffman_decode`

.. doxygenclass:: sptk::HuffmanCoding
   :members:
