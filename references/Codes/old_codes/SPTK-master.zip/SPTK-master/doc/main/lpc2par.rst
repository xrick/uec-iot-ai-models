.. _lpc2par:

lpc2par
=======

.. doxygenfile:: lpc2par.cc

.. seealso:: :ref:`par2lpc`  :ref:`ltcdf`

.. doxygenclass:: sptk::LinearPredictiveCoefficientsToParcorCoefficients
   :members:
