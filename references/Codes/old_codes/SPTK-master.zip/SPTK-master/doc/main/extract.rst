.. _extract:

extract
=======

.. doxygenfile:: extract.cc

.. seealso:: :ref:`lbg`  :ref:`msvq`  :ref:`imsvq`
