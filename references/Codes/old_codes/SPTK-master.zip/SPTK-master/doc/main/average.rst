.. _average:

average
=======

.. doxygenfile:: average.cc

.. seealso:: :ref:`vsum`  :ref:`vstat`
