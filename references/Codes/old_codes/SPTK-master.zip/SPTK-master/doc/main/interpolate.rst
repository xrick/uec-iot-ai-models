.. _interpolate:

interpolate
===========

.. doxygenfile:: interpolate.cc

.. seealso:: :ref:`decimate`
