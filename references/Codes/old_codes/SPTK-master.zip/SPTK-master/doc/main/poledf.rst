.. _poledf:

poledf
======

.. doxygenfile:: poledf.cc

.. seealso:: :ref:`acorr`  :ref:`lpc`

.. doxygenclass:: sptk::AllPoleDigitalFilter
   :members:
