.. _median:

median
======

.. doxygenfile:: median.cc

.. seealso:: :ref:`vstat`  :ref:`medfilt`
