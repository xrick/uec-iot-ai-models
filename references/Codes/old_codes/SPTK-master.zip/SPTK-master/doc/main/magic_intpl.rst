.. _magic_intpl:

magic_intpl
===========

.. doxygenfile:: magic_intpl.cc

.. seealso:: :ref:`pitch`
