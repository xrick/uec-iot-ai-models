.. _ltcdf:

ltcdf
=====

.. doxygenfile:: ltcdf.cc

.. seealso:: :ref:`lpc2par`

.. doxygenclass:: sptk::AllPoleLatticeDigitalFilter
   :members:
