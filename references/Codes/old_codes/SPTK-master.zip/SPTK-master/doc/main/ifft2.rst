.. _ifft2:

ifft2
=====

.. doxygenfile:: ifft2.cc

.. seealso:: :ref:`ifft`  :ref:`fft2`  :ref:`fftr2`

.. doxygenclass:: sptk::TwoDimensionalInverseFastFourierTransform
   :members:
