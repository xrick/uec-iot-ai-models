.. _decimate:

decimate
========

.. doxygenfile:: decimate.cc

.. seealso:: :ref:`interpolate`
