.. _alaw:

alaw
====

.. doxygenfile:: alaw.cc

.. seealso:: :ref:`ialaw`  :ref:`ulaw`

.. doxygenclass:: sptk::ALawCompression
   :members:
