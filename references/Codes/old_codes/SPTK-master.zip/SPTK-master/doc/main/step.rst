.. _step:

step
====

.. doxygenfile:: step.cc

.. seealso:: :ref:`impulse`  :ref:`ramp`  :ref:`train`  :ref:`sin`
