.. _plp:

plp
===

.. doxygenfile:: plp.cc

.. seealso:: :ref:`fbank`  :ref:`mfcc`

.. doxygenclass:: sptk::PerceptualLinearPredictiveCoefficientsAnalysis
   :members:
