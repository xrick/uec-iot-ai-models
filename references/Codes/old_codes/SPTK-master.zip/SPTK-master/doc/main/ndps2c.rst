.. _ndps2c:

ndps2c
======

.. doxygenfile:: ndps2c.cc

.. seealso:: :ref:`c2ndps`

.. doxygenclass:: sptk::NegativeDerivativeOfPhaseSpectrumToCepstrum
   :members:
