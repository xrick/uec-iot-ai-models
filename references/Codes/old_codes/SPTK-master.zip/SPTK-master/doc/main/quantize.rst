.. _quantize:

quantize
========

.. doxygenfile:: quantize.cc

.. seealso:: :ref:`dequantize`

.. doxygenclass:: sptk::UniformQuantization
   :members:
