.. _glogsp:

glogsp
======

.. doxygenfile:: glogsp.py

.. seealso:: :ref:`fdrw`  :ref:`grlogsp`
