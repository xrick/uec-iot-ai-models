.. _zerodf:

zerodf
======

.. doxygenfile:: zerodf.cc

.. seealso:: :ref:`poledf`  :ref:`norm0`

.. doxygenclass:: sptk::AllZeroDigitalFilter
   :members:
