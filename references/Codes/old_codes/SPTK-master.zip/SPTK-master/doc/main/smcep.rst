.. _smcep:

smcep
=====

.. doxygenfile:: smcep.cc

.. seealso:: :ref:`mgcep`

.. doxygenclass:: sptk::SecondOrderAllPassMelCepstralAnalysis
   :members:

.. doxygenclass:: sptk::SecondOrderAllPassFrequencyTransform
   :members:

.. doxygenclass:: sptk::SecondOrderAllPassInverseFrequencyTransform
   :members:
