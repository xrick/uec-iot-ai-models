.. _c2ndps:

c2ndps
======

.. doxygenfile:: c2ndps.cc

.. seealso:: :ref:`ndps2c`

.. doxygenclass:: sptk::CepstrumToNegativeDerivativeOfPhaseSpectrum
   :members:
