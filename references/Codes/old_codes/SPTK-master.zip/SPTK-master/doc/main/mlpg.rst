.. _mlpg:

mlpg
====

.. doxygenfile:: mlpg.cc

.. seealso:: :ref:`delta`

.. doxygenclass:: sptk::RecursiveMaximumLikelihoodParameterGeneration
   :members:

.. doxygenclass:: sptk::NonrecursiveMaximumLikelihoodParameterGeneration
   :members:
