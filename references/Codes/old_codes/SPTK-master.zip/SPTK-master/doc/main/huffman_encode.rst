.. _huffman_encode:

huffman_encode
==============

.. doxygenfile:: huffman_encode.cc

.. seealso:: :ref:`huffman_decode`  :ref:`huffman`

.. doxygenclass:: sptk::HuffmanEncoding
   :members:
