.. _root_pol:

root_pol
========

.. doxygenfile:: root_pol.cc

.. seealso:: :ref:`gpolezero`

.. doxygenclass:: sptk::DurandKernerMethod
   :members:
