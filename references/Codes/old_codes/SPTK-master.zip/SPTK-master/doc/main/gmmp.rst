.. _gmmp:

gmmp
====

.. doxygenfile:: gmmp.cc

.. seealso:: :ref:`gmm`  :ref:`vc`
