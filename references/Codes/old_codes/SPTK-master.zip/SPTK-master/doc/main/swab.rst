.. _swab:

swab
====

.. doxygenfile:: swab.cc
