.. _rmse:

rmse
====

.. doxygenfile:: rmse.cc

.. seealso:: :ref:`cdist`
