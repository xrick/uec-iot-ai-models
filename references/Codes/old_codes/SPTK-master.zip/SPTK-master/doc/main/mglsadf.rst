.. _mglsadf:

mglsadf
=======

.. doxygenfile:: mglsadf.cc

.. seealso:: :ref:`imglsadf`  :ref:`mgcep`

.. doxygenclass:: sptk::MlsaDigitalFilter
   :members:

.. doxygenclass:: sptk::MglsaDigitalFilter
   :members:
