.. _fftcep:

fftcep
======

.. doxygenfile:: fftcep.cc

.. seealso:: :ref:`mgcep`

.. doxygenclass:: sptk::FastFourierTransformCepstralAnalysis
   :members:
