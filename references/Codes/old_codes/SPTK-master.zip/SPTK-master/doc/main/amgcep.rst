.. _amgcep:

amgcep
======

.. doxygenfile:: amgcep.cc

.. seealso:: :ref:`mglsadf`  :ref:`imglsadf`

.. doxygenclass:: sptk::AdaptiveMelCepstralAnalysis
   :members:

.. doxygenclass:: sptk::AdaptiveGeneralizedCepstralAnalysis
   :members:
