.. _pqmf:

pqmf
====

.. doxygenfile:: pqmf.cc

.. seealso:: :ref:`ipqmf`

.. doxygenclass:: sptk::PseudoQuadratureMirrorFilterBanks
   :members:
