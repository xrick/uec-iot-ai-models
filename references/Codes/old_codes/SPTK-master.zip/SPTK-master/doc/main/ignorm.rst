.. _ignorm:

ignorm
======

.. doxygenfile:: ignorm.cc

.. seealso:: :ref:`gnorm`  :ref:`freqt`  :ref:`mgc2mgc`

.. doxygenclass:: sptk::GeneralizedCepstrumInverseGainNormalization
   :members:
