.. _nrand:

nrand
=====

.. doxygenfile:: nrand.cc

.. seealso:: :ref:`mseq`

.. doxygenclass:: sptk::NormalDistributedRandomValueGeneration
   :members:
