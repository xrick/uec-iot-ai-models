.. _delta:

delta
=====

.. doxygenfile:: delta.cc

.. seealso:: :ref:`mlpg`

.. doxygenclass:: sptk::DeltaCalculation
   :members:
