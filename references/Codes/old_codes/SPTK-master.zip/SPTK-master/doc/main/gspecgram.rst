.. _gspecgram:

gspecgram
=========

.. doxygenfile:: gspecgram.py

.. seealso:: :ref:`fdrw`  :ref:`grlogsp`
