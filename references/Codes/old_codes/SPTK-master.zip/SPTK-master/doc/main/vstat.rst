.. _vstat:

vstat
=====

.. doxygenfile:: vstat.cc

.. seealso:: :ref:`vsum`  :ref:`median`

.. doxygenclass:: sptk::StatisticsAccumulation
   :members:
