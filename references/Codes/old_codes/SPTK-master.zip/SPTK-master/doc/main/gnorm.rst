.. _gnorm:

gnorm
=====

.. doxygenfile:: gnorm.cc

.. seealso:: :ref:`ignorm`  :ref:`freqt`  :ref:`mgc2mgc`

.. doxygenclass:: sptk::GeneralizedCepstrumGainNormalization
   :members:
