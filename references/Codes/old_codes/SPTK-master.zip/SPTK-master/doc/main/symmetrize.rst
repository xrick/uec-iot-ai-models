.. _symmetrize:

symmetrize
==========

.. doxygenfile:: symmetrize.cc

.. seealso:: :ref:`transpose`

.. doxygenclass:: sptk::DataSymmetrizing
   :members:
