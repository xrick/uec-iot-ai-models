.. _bcut:

bcut
====

.. doxygenfile:: bcut.cc

.. seealso:: :ref:`bcp`  :ref:`merge`
