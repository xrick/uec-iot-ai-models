.. _norm0:

norm0
=====

.. doxygenfile:: norm0.cc

.. seealso:: :ref:`poledf`  :ref:`zerodf`

.. doxygenclass:: sptk::AllPoleToAllZeroDigitalFilterCoefficients
   :members:
