.. _lpc:

lpc
===

.. doxygenfile:: lpc.cc

.. seealso:: :ref:`acorr`  :ref:`levdur`  :ref:`rlevdur`  :ref:`poledf`
