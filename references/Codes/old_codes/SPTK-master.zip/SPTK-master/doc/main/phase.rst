.. _phase:

phase
=====

.. doxygenfile:: phase.cc

.. seealso:: :ref:`grpdelay`  :ref:`fft`  :ref:`fftr`

.. doxygenclass:: sptk::FilterCoefficientsToPhaseSpectrum
   :members:
