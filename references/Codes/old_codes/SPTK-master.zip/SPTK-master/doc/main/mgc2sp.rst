.. _mgc2sp:

mgc2sp
======

.. doxygenfile:: mgc2sp.cc

.. seealso:: :ref:`mgc2mgc`  :ref:`fftr`

.. doxygenclass:: sptk::MelGeneralizedCepstrumToSpectrum
   :members:
