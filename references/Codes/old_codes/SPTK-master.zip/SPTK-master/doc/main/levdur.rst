.. _levdur:

levdur
======

.. doxygenfile:: levdur.cc

.. seealso:: :ref:`rlevdur`  :ref:`acorr`  :ref:`lpc`

.. doxygenclass:: sptk::LevinsonDurbinRecursion
   :members:
