.. _entropy:

entropy
=======

.. doxygenfile:: entropy.cc

.. seealso:: :ref:`huffman`  :ref:`histogram`

.. doxygenclass:: sptk::EntropyCalculation
   :members:
