.. _spec:

spec
====

.. doxygenfile:: spec.cc

.. seealso:: :ref:`fftr`  :ref:`phase`  :ref:`grpdelay`  :ref:`glogsp`  :ref:`grlogsp`

.. doxygenclass:: sptk::WaveformToSpectrum
   :members:

.. doxygenclass:: sptk::FilterCoefficientsToSpectrum
   :members:

.. doxygenclass:: sptk::SpectrumToSpectrum
   :members:
