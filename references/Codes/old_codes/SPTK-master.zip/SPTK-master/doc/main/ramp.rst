.. _ramp:

ramp
====

.. doxygenfile:: ramp.cc

.. seealso:: :ref:`impulse`  :ref:`step`  :ref:`train`  :ref:`sin`
