.. _dequantize:

dequantize
==========

.. doxygenfile:: dequantize.cc

.. seealso:: :ref:`quantize`

.. doxygenclass:: sptk::InverseUniformQuantization
   :members:
