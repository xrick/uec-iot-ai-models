.. _fdrw:

fdrw
====

.. doxygenfile:: fdrw.py

.. seealso:: :ref:`glogsp`  :ref:`grlogsp`  :ref:`gseries`  :ref:`gwave`  :ref:`gpolezero`
