.. _minmax:

minmax
======

.. doxygenfile:: minmax.cc

.. doxygenclass:: sptk::MinMaxAccumulation
   :members:
