.. _iulaw:

iulaw
=====

.. doxygenfile:: iulaw.cc

.. seealso:: :ref:`ulaw`  :ref:`ialaw`

.. doxygenclass:: sptk::MuLawExpansion
   :members:
