.. _fftr:

fftr
====

.. doxygenfile:: fftr.cc

.. seealso:: :ref:`fft`  :ref:`ifft`  :ref:`spec`  :ref:`phase`  :ref:`grpdelay`

.. doxygenclass:: sptk::RealValuedFastFourierTransform
   :members:

.. doxygenclass:: sptk::RealValuedInverseFastFourierTransform
   :members:
