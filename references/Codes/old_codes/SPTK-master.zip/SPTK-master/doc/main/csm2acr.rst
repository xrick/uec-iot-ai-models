.. _csm2acr:

csm2acr
=======

.. doxygenfile:: csm2acr.cc

.. seealso:: :ref:`acr2csm`  :ref:`acorr`

.. doxygenclass:: sptk::CompositeSinusoidalModelingToAutocorrelation
   :members:
