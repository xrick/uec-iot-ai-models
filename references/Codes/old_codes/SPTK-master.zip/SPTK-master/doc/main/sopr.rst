.. _sopr:

sopr
====

.. doxygenfile:: sopr.cc

.. seealso:: :ref:`vopr`

.. doxygenclass:: sptk::ScalarOperation
   :members:
