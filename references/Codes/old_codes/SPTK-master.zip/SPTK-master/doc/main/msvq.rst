.. _msvq:

msvq
====

.. doxygenfile:: msvq.cc

.. seealso:: :ref:`imsvq`  :ref:`lbg`

.. doxygenclass:: sptk::MultistageVectorQuantization
   :members:

.. doxygenclass:: sptk::VectorQuantization
   :members:
