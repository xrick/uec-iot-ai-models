.. _mgc2mgc:

mgc2mgc
=======

.. doxygenfile:: mgc2mgc.cc

.. seealso:: :ref:`mgcep`  :ref:`freqt`  :ref:`gnorm`  :ref:`ignorm`

.. doxygenclass:: sptk::MelGeneralizedCepstrumToMelGeneralizedCepstrum
   :members:
