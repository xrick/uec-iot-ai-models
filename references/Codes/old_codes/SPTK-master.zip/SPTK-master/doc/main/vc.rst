.. _vc:

vc
==

.. doxygenfile:: vc.cc

.. seealso:: :ref:`gmm`  :ref:`gmmp`

.. doxygenclass:: sptk::GaussianMixtureModelBasedConversion
   :members:
