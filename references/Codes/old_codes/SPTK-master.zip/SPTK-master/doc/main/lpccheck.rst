.. _lpccheck:

lpccheck
========

.. doxygenfile:: lpccheck.cc

.. seealso:: :ref:`lpc2par`  :ref:`lpc`  :ref:`poledf`

.. doxygenclass:: sptk::LinearPredictiveCoefficientsStabilityCheck
   :members:
