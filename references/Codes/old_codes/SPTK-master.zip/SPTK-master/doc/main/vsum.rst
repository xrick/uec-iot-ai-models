.. _vsum:

vsum
====

.. doxygenfile:: vsum.cc

.. seealso:: :ref:`average`  :ref:`vstat`
