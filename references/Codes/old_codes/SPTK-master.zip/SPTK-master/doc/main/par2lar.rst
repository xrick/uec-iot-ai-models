.. _par2lar:

par2lar
=======

.. doxygenfile:: par2lar.cc

.. seealso:: :ref:`lar2par`

.. doxygenclass:: sptk::ParcorCoefficientsToLogAreaRatio
   :members:
