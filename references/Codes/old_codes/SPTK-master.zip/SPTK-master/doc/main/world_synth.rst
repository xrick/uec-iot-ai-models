.. _world_synth:

world_synth
===========

.. doxygenfile:: world_synth.cc

.. seealso:: :ref:`pitch`  :ref:`pitch_spec`  :ref:`ap`

.. doxygenclass:: sptk::WorldSynthesis
   :members:
