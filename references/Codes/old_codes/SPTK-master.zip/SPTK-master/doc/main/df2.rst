.. _df2:

df2
===

.. doxygenfile:: df2.cc

.. seealso:: :ref:`dfs`

.. doxygenclass:: sptk::SecondOrderDigitalFilter
   :members:
