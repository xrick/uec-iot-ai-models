.. _gseries:

gseries
=======

.. doxygenfile:: gseries.py

.. seealso:: :ref:`fdrw`
