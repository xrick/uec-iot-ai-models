.. _dfs:

dfs
===

.. doxygenfile:: dfs.cc

.. seealso:: :ref:`df2`

.. doxygenclass:: sptk::InfiniteImpulseResponseDigitalFilter
   :members:
