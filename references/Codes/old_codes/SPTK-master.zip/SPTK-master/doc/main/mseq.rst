.. _mseq:

mseq
====

.. doxygenfile:: mseq.cc

.. seealso:: :ref:`nrand`

.. doxygenclass:: sptk::MSequenceGeneration
   :members:
