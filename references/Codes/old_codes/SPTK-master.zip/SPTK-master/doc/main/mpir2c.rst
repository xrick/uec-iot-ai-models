.. _mpir2c:

mpir2c
======

.. doxygenfile:: mpir2c.cc

.. seealso:: :ref:`c2mpir`  :ref:`mgc2mgc`

.. doxygenclass:: sptk::MinimumPhaseImpulseResponseToCepstrum
   :members:
