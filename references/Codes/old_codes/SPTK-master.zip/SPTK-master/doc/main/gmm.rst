.. _gmm:

gmm
===

.. doxygenfile:: gmm.cc

.. seealso:: :ref:`lbg`  :ref:`gmmp`  :ref:`vc`

.. doxygenclass:: sptk::GaussianMixtureModeling
   :members:
