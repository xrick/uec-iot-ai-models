.. _window:

window
======

.. doxygenfile:: window.cc

.. seealso:: :ref:`frame`

.. doxygenclass:: sptk::DataWindowing
   :members:
