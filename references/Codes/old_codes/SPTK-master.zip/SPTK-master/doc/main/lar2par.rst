.. _lar2par:

lar2par
=======

.. doxygenfile:: lar2par.cc

.. seealso:: :ref:`par2lar`

.. doxygenclass:: sptk::LogAreaRatioToParcorCoefficients
   :members:
