.. _pcas:

pcas
====

.. doxygenfile:: pcas.cc

.. seealso:: :ref:`pca`
