.. _ap:

ap
==

.. doxygenfile:: ap.cc

.. seealso:: :ref:`pitch`

.. doxygenclass:: sptk::AperiodicityExtraction
   :members:
