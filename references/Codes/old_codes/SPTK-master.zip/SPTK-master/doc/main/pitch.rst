.. _pitch:

pitch
=====

.. doxygenfile:: pitch.cc

.. seealso:: :ref:`pitch_mark`  :ref:`excite`

.. doxygenclass:: sptk::PitchExtraction
   :members:
