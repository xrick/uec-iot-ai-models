.. _mc2b:

mc2b
====

.. doxygenfile:: mc2b.cc

.. seealso:: :ref:`b2mc`  :ref:`mgc2mgc`

.. doxygenclass:: sptk::MelCepstrumToMlsaDigitalFilterCoefficients
   :members:
