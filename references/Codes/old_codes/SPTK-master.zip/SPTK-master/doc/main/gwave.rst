.. _gwave:

gwave
=====

.. doxygenfile:: gwave.py

.. seealso:: :ref:`fdrw`
