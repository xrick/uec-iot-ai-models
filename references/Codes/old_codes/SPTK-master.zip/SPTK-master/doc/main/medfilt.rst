.. _medfilt:

medfilt
=======

.. doxygenfile:: medfilt.cc

.. seealso:: :ref:`median`

.. doxygenclass:: sptk::MedianFilter
   :members:
