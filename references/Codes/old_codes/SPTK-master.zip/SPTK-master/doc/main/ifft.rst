.. _ifft:

ifft
====

.. doxygenfile:: ifft.cc

.. seealso:: :ref:`fft`  :ref:`fftr`

.. doxygenclass:: sptk::InverseFastFourierTransform
   :members:
