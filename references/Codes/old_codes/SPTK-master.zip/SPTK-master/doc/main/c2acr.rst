.. _c2acr:

c2acr
=====

.. doxygenfile:: c2acr.cc

.. seealso:: :ref:`lpc2c`  :ref:`acorr`

.. doxygenclass:: sptk::CepstrumToAutocorrelation
   :members:
