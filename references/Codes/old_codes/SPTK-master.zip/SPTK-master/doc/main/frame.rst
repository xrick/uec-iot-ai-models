.. _frame:

frame
=====

.. doxygenfile:: frame.cc

.. seealso:: :ref:`window`
