.. _lspdf:

lspdf
=====

.. doxygenfile:: lspdf.cc

.. seealso:: :ref:`lpc2lsp`  :ref:`lspcheck`

.. doxygenclass:: sptk::LineSpectralPairsDigitalFilter
   :members:
