.. _imsvq:

imsvq
=====

.. doxygenfile:: imsvq.cc

.. seealso:: :ref:`msvq`  :ref:`lbg`

.. doxygenclass:: sptk::InverseMultistageVectorQuantization
   :members:

.. doxygenclass:: sptk::InverseVectorQuantization
   :members:
