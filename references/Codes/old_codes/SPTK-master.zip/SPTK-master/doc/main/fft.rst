.. _fft:

fft
===

.. doxygenfile:: fft.cc

.. seealso:: :ref:`fftr`  :ref:`ifft`  :ref:`phase`  :ref:`grpdelay`

.. doxygenclass:: sptk::FastFourierTransform
   :members:
