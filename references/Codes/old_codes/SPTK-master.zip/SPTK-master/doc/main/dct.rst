.. _dct:

dct
===

.. doxygenfile:: dct.cc

.. seealso:: :ref:`idct`

.. doxygenclass:: sptk::DiscreteCosineTransform
   :members:
