.. _huffman_decode:

huffman_decode
==============

.. doxygenfile:: huffman_decode.cc

.. seealso:: :ref:`huffman_encode`  :ref:`huffman`

.. doxygenclass:: sptk::HuffmanDecoding
   :members:
