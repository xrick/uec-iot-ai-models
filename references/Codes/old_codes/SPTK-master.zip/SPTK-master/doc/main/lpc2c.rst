.. _lpc2c:

lpc2c
=====

.. doxygenfile:: lpc2c.cc

.. seealso:: :ref:`lpc`  :ref:`mgc2mgc`

.. doxygenclass:: sptk::LinearPredictiveCoefficientsToCepstrum
   :members:
