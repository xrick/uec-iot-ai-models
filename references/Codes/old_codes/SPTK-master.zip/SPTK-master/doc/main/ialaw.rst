.. _ialaw:

ialaw
=====

.. doxygenfile:: ialaw.cc

.. seealso:: :ref:`alaw`  :ref:`iulaw`

.. doxygenclass:: sptk::ALawExpansion
   :members:
