.. _b2mc:

b2mc
====

.. doxygenfile:: b2mc.cc

.. seealso:: :ref:`mc2b`  :ref:`mgcep`

.. doxygenclass:: sptk::MlsaDigitalFilterCoefficientsToMelCepstrum
   :members:
