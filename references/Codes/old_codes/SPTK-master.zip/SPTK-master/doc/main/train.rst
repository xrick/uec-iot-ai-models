.. _train:

train
=====

.. doxygenfile:: train.cc

.. seealso:: :ref:`excite`
