.. _lpc2lsp:

lpc2lsp
=======

.. doxygenfile:: lpc2lsp.cc

.. seealso:: :ref:`lsp2lpc`  :ref:`lspdf`

.. doxygenclass:: sptk::LinearPredictiveCoefficientsToLineSpectralPairs
   :members:
