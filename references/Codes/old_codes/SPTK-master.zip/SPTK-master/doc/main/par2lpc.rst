.. _par2lpc:

par2lpc
=======

.. doxygenfile:: par2lpc.cc

.. seealso:: :ref:`lpc`  :ref:`lpc2par`

.. doxygenclass:: sptk::ParcorCoefficientsToLinearPredictiveCoefficients
   :members:
