.. _lbg:

lbg
===

.. doxygenfile:: lbg.cc

.. seealso:: :ref:`imsvq`  :ref:`msvq`  :ref:`gmm`  :ref:`extract`

.. doxygenclass:: sptk::LindeBuzoGrayAlgorithm
   :members:
