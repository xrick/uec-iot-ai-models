.. _mfcc:

mfcc
====

.. doxygenfile:: mfcc.cc

.. seealso:: :ref:`fbank`  :ref:`plp`

.. doxygenclass:: sptk::MelFrequencyCepstralCoefficientsAnalysis
   :members:
