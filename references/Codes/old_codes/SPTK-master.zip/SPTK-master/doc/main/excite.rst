.. _excite:

excite
======

.. doxygenfile:: excite.cc

.. seealso:: :ref:`train`  :ref:`nrand`  :ref:`pitch`

.. doxygenclass:: sptk::ExcitationGeneration
   :members:
