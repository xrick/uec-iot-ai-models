.. _idct:

idct
====

.. doxygenfile:: idct.cc

.. seealso:: :ref:`dct`

.. doxygenclass:: sptk::InverseDiscreteCosineTransform
   :members:
