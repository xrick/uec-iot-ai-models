.. _rlevdur:

rlevdur
=======

.. doxygenfile:: rlevdur.cc

.. seealso:: :ref:`levdur`

.. doxygenclass:: sptk::ReverseLevinsonDurbinRecursion
   :members:
