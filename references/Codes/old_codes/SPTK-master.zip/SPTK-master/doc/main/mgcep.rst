.. _mgcep:

mgcep
=====

.. doxygenfile:: mgcep.cc

.. seealso:: :ref:`fftcep`  :ref:`mglsadf`  :ref:`imglsadf`  :ref:`mgc2mgc`  :ref:`smcep`

.. doxygenclass:: sptk::MelCepstralAnalysis
   :members:

.. doxygenclass:: sptk::MelGeneralizedCepstralAnalysis
   :members:
