.. _lspcheck:

lspcheck
========

.. doxygenfile:: lspcheck.cc

.. seealso:: :ref:`lspdf`  :ref:`lpc2lsp`  :ref:`lsp2lpc`

.. doxygenclass:: sptk::LineSpectralPairsStabilityCheck
   :members:
