.. _acr2csm:

acr2csm
=======

.. doxygenfile:: acr2csm.cc

.. seealso:: :ref:`csm2acr`  :ref:`acorr`

.. doxygenclass:: sptk::AutocorrelationToCompositeSinusoidalModeling
   :members:
