.. _pca:

pca
===

.. doxygenfile:: pca.cc

.. seealso:: :ref:`pcas`

.. doxygenclass:: sptk::PrincipalComponentAnalysis
   :members:
