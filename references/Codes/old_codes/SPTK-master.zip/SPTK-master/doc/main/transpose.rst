.. _transpose:

transpose
=========

.. doxygenfile:: transpose.cc

.. seealso:: :ref:`symmetrize`
