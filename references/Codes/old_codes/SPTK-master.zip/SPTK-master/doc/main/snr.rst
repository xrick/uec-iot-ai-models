.. _snr:

snr
===

.. doxygenfile:: snr.cc

.. seealso:: :ref:`rmse`
