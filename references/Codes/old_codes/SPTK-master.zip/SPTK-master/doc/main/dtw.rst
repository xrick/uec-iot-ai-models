.. _dtw:

dtw
===

.. doxygenfile:: dtw.cc

.. seealso:: :ref:`dtw_merge`

.. doxygenclass:: sptk::DynamicTimeWarping
   :members:

.. doxygenclass:: sptk::DistanceCalculation
   :members:
