.. _mglsp2sp:

mglsp2sp
========

.. doxygenfile:: mglsp2sp.cc

.. seealso:: :ref:`lpc2lsp`

.. doxygenclass:: sptk::MelGeneralizedLineSpectralPairsToSpectrum
   :members:
