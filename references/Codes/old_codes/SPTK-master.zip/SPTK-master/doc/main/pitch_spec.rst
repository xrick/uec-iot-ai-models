.. _pitch_spec:

pitch_spec
==========

.. doxygenfile:: pitch_spec.cc

.. seealso:: :ref:`spec`  :ref:`pitch`

.. doxygenclass:: sptk::SpectrumExtraction
   :members:
