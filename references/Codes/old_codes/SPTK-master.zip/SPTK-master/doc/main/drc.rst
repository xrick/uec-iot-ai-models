.. _drc:

drc
===

.. doxygenfile:: drc.cc

.. doxygenclass:: sptk::DynamicRangeCompression
   :members:
