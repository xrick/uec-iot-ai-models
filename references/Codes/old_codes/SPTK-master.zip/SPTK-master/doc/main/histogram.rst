.. _histogram:

histogram
=========

.. doxygenfile:: histogram.cc

.. seealso:: :ref:`entropy`

.. doxygenclass:: sptk::HistogramCalculation
   :members:
