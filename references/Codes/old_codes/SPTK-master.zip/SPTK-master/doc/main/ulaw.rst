.. _ulaw:

ulaw
====

.. doxygenfile:: ulaw.cc

.. seealso:: :ref:`iulaw`  :ref:`alaw`

.. doxygenclass:: sptk::MuLawCompression
   :members:
