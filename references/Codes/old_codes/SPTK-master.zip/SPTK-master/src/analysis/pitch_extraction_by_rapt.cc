// ------------------------------------------------------------------------ //
// Copyright 2021 SPTK Working Group                                        //
//                                                                          //
// Licensed under the Apache License, Version 2.0 (the "License");          //
// you may not use this file except in compliance with the License.         //
// You may obtain a copy of the License at                                  //
//                                                                          //
//     http://www.apache.org/licenses/LICENSE-2.0                           //
//                                                                          //
// Unless required by applicable law or agreed to in writing, software      //
// distributed under the License is distributed on an "AS IS" BASIS,        //
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
// See the License for the specific language governing permissions and      //
// limitations under the License.                                           //
// ------------------------------------------------------------------------ //

#include "SPTK/analysis/pitch_extraction_by_rapt.h"

#include <algorithm>  // std::copy, std::fill
#include <cmath>      // std::ceil

#include "Snack/jkGetF0.h"

namespace sptk {

PitchExtractionByRapt::PitchExtractionByRapt(int frame_shift,
                                             double sampling_rate,
                                             double lower_f0, double upper_f0,
                                             double voicing_threshold)
    : frame_shift_(frame_shift),
      sampling_rate_(sampling_rate),
      lower_f0_(lower_f0),
      upper_f0_(upper_f0),
      voicing_threshold_(voicing_threshold),
      is_valid_(true) {
  if (frame_shift_ <= 0 || sampling_rate_ / 2 <= upper_f0_ ||
      (sampling_rate_ <= 6000.0 || 98000.0 < sampling_rate_) ||
      (lower_f0_ <= 10.0 || upper_f0_ <= lower_f0_)) {
    is_valid_ = false;
    return;
  }
}

bool PitchExtractionByRapt::Get(
    const std::vector<double>& waveform, std::vector<double>* f0,
    std::vector<double>* epochs,
    PitchExtractionInterface::Polarity* polarity) const {
  // Check inputs.
  if (!is_valid_ || waveform.empty()) {
    return false;
  }

  if (NULL != f0) {
    float* tmp_f0;
    int tmp_length;
    if (0 != snack::cGet_f0(waveform, frame_shift_, sampling_rate_, lower_f0_,
                            upper_f0_, voicing_threshold_, &tmp_f0,
                            &tmp_length)) {
      return false;
    }
    const int target_length(static_cast<int>(
        std::ceil(static_cast<double>(waveform.size()) / frame_shift_)));
    if (target_length < tmp_length) {
      tmp_length = target_length;
    }
    f0->resize(target_length);
    std::copy(tmp_f0, tmp_f0 + tmp_length, f0->begin());
    std::fill(f0->begin() + tmp_length, f0->end(), tmp_f0[tmp_length - 1]);
    snack::ckfree(tmp_f0);
  }

  if (NULL != epochs) {
    // nothing to do
  }

  if (NULL != polarity) {
    // nothing to do
  }

  return true;
}

}  // namespace sptk
