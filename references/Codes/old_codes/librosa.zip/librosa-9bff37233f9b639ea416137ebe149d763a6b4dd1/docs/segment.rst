.. _segment:

.. automodule:: librosa.segment
