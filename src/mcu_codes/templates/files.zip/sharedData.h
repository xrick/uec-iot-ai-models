//#pragma once
//#include <cstdint>
//#include <cstddef>
#include <stdint.h>
#include <stdlib.h>

//define return struct
struct RetResult
{
    unsigned int inputNumber; // = 0;
    size_t max_idx; //  = 0;
    int8_t max_value; // = -128;
		int8_t min_value;

};